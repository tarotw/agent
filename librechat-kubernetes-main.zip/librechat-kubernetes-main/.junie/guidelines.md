# LibreChat Kubernetes Development Guidelines

## Build/Configuration Instructions

### Docker Build Process
The project uses a multi-platform Docker build process with the following characteristics:
- **Base Image**: `ghcr.io/danny-avila/librechat:v0.7.9-rc1`
- **Additional Tools**: Docker, Git, and kubectl are installed in the container
- **Platforms**: Supports both `linux/amd64` and `linux/arm64`
- **Registry**: Images are pushed to `docker.io/iunera/librechat`
- **Versioning**: Version is extracted from `helm/librechat/Chart.yaml` and used for Docker tags

### Helm Chart Configuration
The project contains two main Helm charts:
1. **librechat** (main chart) - version 1.8.9
2. **librechat-rag-api** (dependency chart) - version 0.5.2

#### Dependencies
- **MongoDB**: bitnami/mongodb v16.3.0 (optional)
- **Meilisearch**: meilisearch/meilisearch v0.11.0 (optional)
- **LibreChat RAG API**: Local chart dependency v0.5.2 (optional)

#### Required Secrets
Generate the following secrets using OpenSSL:
```bash
# Generate 32-byte hex values
openssl rand -hex 32  # For CREDS_KEY, JWT_SECRET, JWT_REFRESH_SECRET, MEILI_MASTER_KEY
# Generate 16-byte hex value
openssl rand -hex 16  # For CREDS_IV
```

Create a Kubernetes secret:
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: librechat-credentials-env
  namespace: <namespace>
type: Opaque
stringData:
  CREDS_KEY: "<generated-value>"
  CREDS_IV: "<generated-value>"
  JWT_SECRET: "<generated-value>"
  JWT_REFRESH_SECRET: "<generated-value>"
  MEILI_MASTER_KEY: "<generated-value>"
  OPENAI_API_KEY: "<your-api-key>"
```

## Testing Information

### Chart Testing Configuration
The project uses `chart-testing` (ct) with configuration in `_ct.yaml`:
- **Target Branch**: main
- **Chart Directories**: helm/
- **Repositories**: bitnami, meilisearch
- **Timeout**: 600s
- **Validation**: Schema, YAML (maintainers validation disabled)

### Running Tests

#### 1. Chart Linting
```bash
# Lint charts using chart-testing
ct lint --config _ct.yaml

# Basic Helm linting
helm lint helm/librechat/
helm lint helm/librechat-rag-api/
```

#### 2. Simple Test Demo
A basic test script is available to demonstrate testing capabilities:
```bash
# Make executable and run
chmod +x simple-test-demo.sh
./simple-test-demo.sh
```

This script performs:
- Tool availability checks (helm, ct)
- Helm chart syntax validation
- Template rendering tests
- Configuration validation

#### 3. Full Integration Testing
For comprehensive testing with Kind cluster:
```bash
# Run the full test suite
./helm/librechat/test/test-chart.sh

# Cleanup after testing
./helm/librechat/test/test-chart.sh --cleanup
```

The integration test:
- Creates a Kind cluster with port mapping (30080)
- Installs chart dependencies
- Deploys with test configuration
- Runs connectivity tests
- Provides cleanup functionality

### Adding New Tests
When adding new tests:
1. Follow the existing pattern in `helm/librechat/test/test-chart.sh`
2. Use colored output for better visibility (RED, GREEN, YELLOW)
3. Include proper error handling with `set -e`
4. Provide cleanup functionality
5. Test with minimal resource requirements for CI/CD

### CI/CD Testing
The project uses GitHub Actions for automated testing:
- **Trigger**: Changes to `helm/**`, workflow files, or `_ct.yaml`
- **Process**: 
  1. Chart linting with `ct lint`
  2. Kind cluster creation
  3. Cert-manager CRD installation
  4. Dependency installation
  5. Chart installation with `ct install`
  6. Additional connectivity tests
  7. Automatic cleanup

## Additional Development Information

### Known Issues
1. **librechat-rag-api Chart**: Has template issues with `.Values.global.librechat.existingSecretName` (nil pointer evaluation)
2. **Chart Versioning**: ct lint requires version bumps when charts are modified
3. **YAML Linting**: Ensure all YAML files end with a newline character

### Code Style and Conventions
- **Helm Templates**: Follow standard Helm templating practices
- **YAML Files**: Must end with newline character (yamllint requirement)
- **Chart Versioning**: Use semantic versioning for chart versions
- **Secret Management**: Always use Kubernetes secrets for sensitive data
- **Resource Limits**: Define appropriate resource limits and requests

### Development Workflow
1. **Local Development**: Use the test script for quick validation
2. **Chart Changes**: Always bump chart version when making changes
3. **Dependencies**: Update `Chart.lock` when modifying dependencies
4. **Testing**: Run both lint and integration tests before submitting PRs
5. **Documentation**: Update chart README files when adding new features

### Debugging Tips
- Use `helm template` with `--dry-run` for template debugging
- Check `kubectl get all -n <namespace>` for resource status
- Use `helm test` for built-in chart tests
- Enable debug mode in `_ct.yaml` for verbose output
- Check pod logs with `kubectl logs` for runtime issues

### Repository Structure
```
├── Dockerfile                          # Multi-platform container build
├── _ct.yaml                           # Chart testing configuration
├── helm/
│   ├── librechat/                     # Main Helm chart
│   │   ├── Chart.yaml                 # Chart metadata and dependencies
│   │   ├── values.yaml                # Default configuration values
│   │   ├── templates/                 # Kubernetes manifests
│   │   ├── test/test-chart.sh         # Integration test script
│   │   └── readme.md                  # Chart documentation
│   └── librechat-rag-api/             # RAG API subchart
└── .github/workflows/                 # CI/CD automation
    ├── docker-build.yml               # Docker image build and push
    └── helm-test.yml                  # Chart testing workflow
```

### Environment Variables
LibreChat requires environment-based configuration. Key variables:
- **Authentication**: `CREDS_KEY`, `CREDS_IV`, `JWT_SECRET`, `JWT_REFRESH_SECRET`
- **Search**: `MEILI_MASTER_KEY`
- **AI Providers**: `OPENAI_API_KEY` (and others as needed)

All sensitive values should be stored in Kubernetes secrets and referenced in the Helm values.