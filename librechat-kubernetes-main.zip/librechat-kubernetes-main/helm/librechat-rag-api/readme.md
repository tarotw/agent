# LibreChat RAG API Helm Chart

This Helm chart provides the RAG (Retrieval-Augmented Generation) API component for LibreChat, enabling context-aware responses based on user-uploaded files.

## Chart Information

- **Chart Version**: 0.5.3
- **App Version**: v0.4.0
- **Home**: https://www.librechat.ai

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+
- PV provisioner support in the underlying infrastructure (if persistence is enabled)

## Dependencies

This chart has the following optional dependencies:

| Repository | Name | Version | Condition |
|------------|------|---------|-----------|
| https://charts.bitnami.com/bitnami | postgresql | 15.5.38 | `postgresql.enabled` |

## Overview

The LibreChat RAG API provides:
- Vector database functionality using PostgreSQL with pgvector extension
- Support for multiple embeddings providers (OpenAI, Azure, Hugging Face)
- File upload and processing capabilities
- Context-aware response generation

> [!NOTE]  
> This chart is typically deployed as a dependency of the main LibreChat chart. For complete deployment instructions, see the [main LibreChat chart documentation](../librechat/readme.md).

## Installation

### As a Dependency

The RAG API is usually installed as a dependency of the main LibreChat chart:

```yaml
# In LibreChat values.yaml
librechat-rag-api:
  enabled: true
  embeddingsProvider: openai
```

### Standalone Installation

If you need to install the RAG API separately:

```bash
# Add required Helm repositories
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

# Update chart dependencies
cd helm/librechat-rag-api
helm dependency update

# Install the chart
helm install librechat-rag-api ./helm/librechat-rag-api
```

## Configuration

The following table lists the configurable parameters of the LibreChat RAG API chart and their default values.

### RAG Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `rag.enabled` | Enable RAG functionality | `true` |
| `rag.existingSecret` | Name of existing secret for RAG configuration | `""` |
| `rag.configEnv.DB_PORT` | Database port | `"5432"` |
| `rag.configEnv.EMBEDDINGS_PROVIDER` | Embeddings provider (openai, azure, huggingface, huggingfacetei) | `"openai"` |

### Image Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | RAG API image repository | `"danny-avila/librechat-rag-api-dev-lite"` |
| `image.registry` | RAG API image registry | `"ghcr.io"` |
| `image.pullPolicy` | Image pull policy | `"IfNotPresent"` |
| `image.tag` | RAG API image tag (overrides appVersion) | `"latest"` |
| `imagePullSecrets` | Image pull secrets | `[]` |

### Deployment Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `nameOverride` | Override the name of the chart | `""` |
| `fullnameOverride` | Override the full name of the chart | `""` |

### Pod Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `podAnnotations` | Pod annotations | `{}` |
| `podLabels` | Pod labels | `{}` |
| `podSecurityContext` | Pod security context | `{}` |
| `securityContext` | Container security context | `{}` |

### Service Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `service.type` | Kubernetes service type | `"ClusterIP"` |
| `service.port` | Service port | `8000` |
| `service.annotations` | Service annotations | `{}` |

### Resource Management

| Parameter | Description | Default |
|-----------|-------------|---------|
| `resources` | CPU/Memory resource requests/limits | `{}` |
| `nodeSelector` | Node selector for pod assignment | `{}` |
| `tolerations` | Tolerations for pod assignment | `[]` |
| `affinity` | Affinity rules for pod assignment | `{}` |

### Storage

| Parameter | Description | Default |
|-----------|-------------|---------|
| `volumes` | Additional volumes | `[]` |
| `volumeMounts` | Additional volume mounts | `[]` |

### PostgreSQL Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `postgresql.enabled` | Enable PostgreSQL dependency | `true` |
| `postgresql.image.registry` | PostgreSQL image registry | `"ghcr.io"` |
| `postgresql.image.repository` | PostgreSQL image repository | `"bat-bs/bitnami-pgvector"` |
| `postgresql.image.tag` | PostgreSQL image tag | `"pg16"` |
| `postgresql.auth.database` | PostgreSQL database name | `"librechat-vectordb"` |
| `postgresql.auth.username` | PostgreSQL username | `"postgres"` |
| `postgresql.auth.existingSecret` | Existing secret for PostgreSQL credentials | `"librechat-vectordb"` |
| `postgresql.auth.existingSecretKey` | Key in existing secret for PostgreSQL password | `"postgres-password"` |

### Additional Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `extraContainers` | Additional containers to run alongside the RAG API | `{}` |

## Embeddings Providers

The RAG API supports multiple embeddings providers:

### OpenAI
```yaml
rag:
  configEnv:
    EMBEDDINGS_PROVIDER: openai
```
Requires `OPENAI_API_KEY` in your secrets.

### Azure OpenAI
```yaml
rag:
  configEnv:
    EMBEDDINGS_PROVIDER: azure
```
Requires Azure OpenAI configuration in your secrets.

### Hugging Face
```yaml
rag:
  configEnv:
    EMBEDDINGS_PROVIDER: huggingface
```
Requires `HUGGINGFACE_API_KEY` in your secrets.

### Hugging Face TEI (Text Embeddings Inference)
```yaml
rag:
  configEnv:
    EMBEDDINGS_PROVIDER: huggingfacetei
```
For self-hosted Hugging Face TEI endpoints.

## Required Secrets

The RAG API requires database credentials. Create a secret for PostgreSQL:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: librechat-vectordb
  namespace: <your-namespace>
type: Opaque
stringData:
  postgres-password: "<your-postgres-password>"
  password: "<your-user-password>"
  replication-password: "<your-replication-password>"
```

## Health Checks

The chart supports optional health checks (currently commented out in values.yaml):

```yaml
livenessProbe:
  httpGet:
    path: /
    port: http
readinessProbe:
  httpGet:
    path: /
    port: http
```

## Usage with LibreChat

When enabled in the main LibreChat chart, the RAG API provides:

1. **File Upload Processing**: Processes uploaded documents and creates vector embeddings
2. **Context Retrieval**: Retrieves relevant context based on user queries
3. **Enhanced Responses**: Enables LibreChat to provide context-aware responses

## Troubleshooting

### Common Issues

1. **Database Connection Issues**: 
   - Verify PostgreSQL is running and accessible
   - Check database credentials in the secret
   - Ensure pgvector extension is enabled

2. **Embeddings Provider Issues**:
   - Verify API keys are correctly set in secrets
   - Check embeddings provider configuration
   - Ensure network connectivity to provider APIs

3. **Image Pull Issues**:
   - Verify image repository and tag settings
   - Check image pull secrets if using private registries

### Debugging

- Use `kubectl logs` to check RAG API pod logs
- Use `kubectl describe` to check pod/service status
- Verify PostgreSQL connectivity: `kubectl exec -it <postgres-pod> -- psql -U postgres -d librechat-vectordb`
- Check if pgvector extension is enabled: `SELECT * FROM pg_extension WHERE extname = 'vector';`

## Upgrading

To upgrade the chart:

```bash
helm upgrade librechat-rag-api ./helm/librechat-rag-api -f custom-values.yaml
```

## Uninstalling

To uninstall the chart:

```bash
helm uninstall librechat-rag-api
```

Note: This will also remove the PostgreSQL database and all vector data unless persistence is configured to retain data.

## Development

### Image Variants

The chart supports different image variants:
- `librechat-rag-api-dev`: Full development version
- `librechat-rag-api-dev-lite`: Lightweight version (default)

### Custom Configuration

You can extend the RAG API configuration by:

1. Adding custom environment variables via `rag.configEnv`
2. Mounting additional volumes for custom configurations
3. Using `extraContainers` for additional services

## Integration Notes

- The RAG API is designed to work seamlessly with the main LibreChat application
- Vector embeddings are stored in PostgreSQL with the pgvector extension
- File processing and embedding generation happen asynchronously
- The API provides REST endpoints for LibreChat to interact with the vector database