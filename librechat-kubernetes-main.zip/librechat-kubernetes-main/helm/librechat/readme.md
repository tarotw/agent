# LibreChat Helm Chart

This Helm chart provides an easy, lightweight template to deploy LibreChat on Kubernetes.

## Chart Information

- **Chart Version**: 1.8.10
- **App Version**: v0.7.9
- **Home**: https://github.com/iunera/librechat-kubernetes

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+
- PV provisioner support in the underlying infrastructure (if persistence is enabled)

## Dependencies

This chart has the following optional dependencies:

| Repository | Name | Version | Condition |
|------------|------|---------|-----------|
| https://charts.bitnami.com/bitnami | mongodb | 16.3.0 | `mongodb.enabled` |
| https://meilisearch.github.io/meilisearch-kubernetes | meilisearch | 0.11.0 | `meilisearch.enabled` |
| file://../librechat-rag-api | librechat-rag-api | 0.5.3 | `librechat-rag-api.enabled` |

## Installation

### Step 1: Create Required Secrets

LibreChat requires several secrets for proper operation. Generate the required values:

```bash
# Generate 32-byte hex values
openssl rand -hex 32  # For CREDS_KEY, JWT_SECRET, JWT_REFRESH_SECRET, MEILI_MASTER_KEY
# Generate 16-byte hex value
openssl rand -hex 16  # For CREDS_IV
```

Create a Kubernetes secret:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: librechat-credentials-env
  namespace: <your-namespace>
type: Opaque
stringData:
  CREDS_KEY: "<generated-32-byte-hex>"
  CREDS_IV: "<generated-16-byte-hex>"
  JWT_SECRET: "<generated-32-byte-hex>"
  JWT_REFRESH_SECRET: "<generated-32-byte-hex>"
  MEILI_MASTER_KEY: "<generated-32-byte-hex>"
  OPENAI_API_KEY: "<your-openai-api-key>"
  # Add other AI provider API keys as needed
```

Apply the secret:
```bash
kubectl apply -f librechat-credentials-env.secret.yaml
```

### Step 2: Add Helm Repository Dependencies

```bash
# Add required Helm repositories
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo add meilisearch https://meilisearch.github.io/meilisearch-kubernetes
helm repo update
```

### Step 3: Install Dependencies

```bash
# Update chart dependencies
cd helm/librechat
helm dependency update
```

### Step 4: Install the Chart

```bash
# Install with default values
helm install librechat ./helm/librechat

# Or install with custom values
helm install librechat ./helm/librechat -f custom-values.yaml
```

## Configuration

The following table lists the configurable parameters of the LibreChat chart and their default values.

### Global Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `global.librechat.existingSecretName` | Name of existing secret containing environment variables | `"librechat-credentials-env"` |
| `global.librechat.existingSecretApiKey` | Key name in the secret for the API key | `"OPENAI_API_KEY"` |

### LibreChat Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `librechat.configEnv` | Environment variables for LibreChat configuration | See values.yaml |
| `librechat.existingSecretName` | Name of existing secret containing environment variables | `"librechat-credentials-env"` |
| `librechat.configYamlContent` | Custom LibreChat YAML configuration content | `""` |
| `librechat.existingConfigYaml` | Name of existing ConfigMap with librechat.yaml | `""` |

### Image Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | LibreChat image repository | `"iunera/librechat"` |
| `image.registry` | LibreChat image registry | `"docker.io"` |
| `image.pullPolicy` | Image pull policy | `"IfNotPresent"` |
| `image.tag` | LibreChat image tag (overrides appVersion) | `""` |
| `imagePullSecrets` | Image pull secrets | `[]` |

### Deployment Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of LibreChat replicas | `1` |
| `nameOverride` | Override the name of the chart | `""` |
| `fullnameOverride` | Override the full name of the chart | `""` |
| `updateStrategy.type` | Deployment update strategy | `"RollingUpdate"` |

### Service Account and RBAC

| Parameter | Description | Default |
|-----------|-------------|---------|
| `serviceAccount.create` | Create a service account | `false` |
| `serviceAccount.automount` | Automatically mount service account API credentials | `true` |
| `serviceAccount.annotations` | Service account annotations | `{}` |
| `serviceAccount.name` | Service account name | `""` |
| `rbac.create` | Create RBAC resources | `false` |
| `rbac.kind` | Type of RBAC resource ("Role" or "ClusterRole") | `"Role"` |
| `rbac.allowServiceManagement` | Allow managing services for MCP servers | `false` |
| `rbac.allowConfigMapManagement` | Allow managing configmaps | `true` |
| `rbac.allowSecretManagement` | Allow managing secrets | `false` |
| `rbac.allowDeploymentManagement` | Allow managing deployments | `false` |
| `rbac.additionalRules` | Additional custom RBAC rules | `[]` |

### Pod Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `podAnnotations` | Pod annotations | `{}` |
| `podLabels` | Pod labels | `{}` |
| `podSecurityContext.fsGroup` | Pod security context fsGroup | `2000` |
| `securityContext.capabilities.drop` | Capabilities to drop | `["ALL"]` |
| `securityContext.runAsNonRoot` | Run as non-root user | `true` |
| `securityContext.runAsUser` | User ID to run as | `1000` |
| `lifecycle` | Pod lifecycle hooks | `{}` |

### Service Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `service.type` | Kubernetes service type | `"ClusterIP"` |
| `service.port` | Service port | `3080` |
| `service.annotations` | Service annotations | `{}` |

### Ingress Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `ingress.enabled` | Enable ingress | `false` |
| `ingress.className` | Ingress class name | `""` |
| `ingress.annotations` | Ingress annotations | `{}` |
| `ingress.hosts` | Ingress hosts configuration | See values.yaml |
| `ingress.tls` | Ingress TLS configuration | `[]` |

### Resource Management

| Parameter | Description | Default |
|-----------|-------------|---------|
| `resources` | CPU/Memory resource requests/limits | `{}` |
| `nodeSelector` | Node selector for pod assignment | `{}` |
| `tolerations` | Tolerations for pod assignment | `[]` |
| `affinity` | Affinity rules for pod assignment | `{}` |

### Autoscaling

| Parameter | Description | Default |
|-----------|-------------|---------|
| `autoscaling.enabled` | Enable horizontal pod autoscaler | `false` |
| `autoscaling.minReplicas` | Minimum number of replicas | `1` |
| `autoscaling.maxReplicas` | Maximum number of replicas | `100` |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage | `80` |

### Health Checks

| Parameter | Description | Default |
|-----------|-------------|---------|
| `livenessProbe.httpGet.path` | Liveness probe HTTP path | `"/health"` |
| `livenessProbe.httpGet.port` | Liveness probe HTTP port | `"http"` |
| `livenessProbe.initialDelaySeconds` | Initial delay for liveness probe | `60` |
| `livenessProbe.periodSeconds` | Period for liveness probe | `10` |
| `livenessProbe.timeoutSeconds` | Timeout for liveness probe | `60` |
| `livenessProbe.failureThreshold` | Failure threshold for liveness probe | `3` |
| `readinessProbe.httpGet.path` | Readiness probe HTTP path | `"/health"` |
| `readinessProbe.httpGet.port` | Readiness probe HTTP port | `"http"` |
| `readinessProbe.initialDelaySeconds` | Initial delay for readiness probe | `5` |
| `readinessProbe.periodSeconds` | Period for readiness probe | `5` |
| `readinessProbe.timeoutSeconds` | Timeout for readiness probe | `10` |
| `readinessProbe.failureThreshold` | Failure threshold for readiness probe | `3` |

### Storage

| Parameter | Description | Default |
|-----------|-------------|---------|
| `librechat.imageVolume.enabled` | Enable persistent volume for uploaded images | `true` |
| `librechat.imageVolume.size` | Size of the image volume | `"10G"` |
| `librechat.imageVolume.accessModes` | Access modes for the volume | `"ReadWriteOnce"` |
| `librechat.imageVolume.retain` | Retain PVC when Helm release is uninstalled | `false` |
| `volumes` | Additional volumes | `[]` |
| `volumeMounts` | Additional volume mounts | `[]` |

### Dependencies Configuration

#### MongoDB

| Parameter | Description | Default |
|-----------|-------------|---------|
| `mongodb.enabled` | Enable MongoDB dependency | `true` |
| `mongodb.auth.enabled` | Enable MongoDB authentication | `false` |
| `mongodb.databases` | MongoDB databases to create | `["LibreChat"]` |

#### Meilisearch

| Parameter | Description | Default |
|-----------|-------------|---------|
| `meilisearch.enabled` | Enable Meilisearch dependency | `true` |
| `meilisearch.persistence.enabled` | Enable Meilisearch persistence | `true` |
| `meilisearch.image.tag` | Meilisearch image tag | `"v1.7.3"` |
| `meilisearch.auth.existingMasterKeySecret` | Existing secret for MEILI_MASTER_KEY | `"librechat-credentials-env"` |
| `createMeilisearchExistingPvc` | Create existing PVC for Meilisearch | `null` |

#### LibreChat RAG API

| Parameter | Description | Default |
|-----------|-------------|---------|
| `librechat-rag-api.enabled` | Enable RAG API dependency | `false` |
| `librechat-rag-api.embeddingsProvider` | Embeddings provider (azure, openai, huggingface, huggingfacetei) | `"openai"` |

## Environment Variables

LibreChat supports extensive configuration through environment variables. Key variables include:

### Required Variables (stored in secrets)
- `CREDS_KEY`: 32-byte hex encryption key
- `CREDS_IV`: 16-byte hex initialization vector
- `JWT_SECRET`: 32-byte hex JWT secret
- `JWT_REFRESH_SECRET`: 32-byte hex JWT refresh secret
- `MEILI_MASTER_KEY`: 32-byte hex Meilisearch master key

### AI Provider API Keys
- `OPENAI_API_KEY`: OpenAI API key
- `AZURE_API_KEY`: Azure OpenAI API key
- `ANTHROPIC_API_KEY`: Anthropic API key
- `GOOGLE_API_KEY`: Google AI API key
- And others as needed

### Optional Configuration Variables
- `PLUGIN_MODELS`: Comma-separated list of models supporting plugins
- `DEBUG_PLUGINS`: Enable plugin debugging
- Custom environment variables can be added via `librechat.configEnv`

## Custom Configuration

### LibreChat YAML Configuration

You can provide a custom LibreChat configuration using either:

1. **Inline configuration** via `librechat.configYamlContent`:
```yaml
librechat:
  configYamlContent: |
    version: 1.0.8
    cache: true
    interface:
      privacyPolicy:
        externalUrl: 'https://librechat.ai/privacy-policy'
        openNewTab: true
    endpoints:
      azureOpenAI:
        titleModel: "gpt-4o"
        plugins: true
```

2. **Existing ConfigMap** via `librechat.existingConfigYaml`:
```yaml
librechat:
  existingConfigYaml: "my-librechat-config"
```

## Development and Testing

### Automated Testing
This chart is automatically tested using GitHub Actions workflow that:
1. Lints the chart using chart-testing (ct)
2. Installs the chart in a Kind (Kubernetes in Docker) cluster
3. Runs tests to verify the installation

The workflow is triggered on pull requests that modify files in the `helm/` directory.

### Local Testing
You can test the chart locally using the provided test script:

```bash
# From the repository root
./helm/librechat/test/test-chart.sh
```

This script will:
1. Check for required tools (Helm, Kind, kubectl)
2. Run Helm lint on the chart
3. Create a Kind cluster
4. Install chart dependencies
5. Install the chart with test values
6. Test the chart installation
7. Clean up resources

To clean up resources without running tests:
```bash
./helm/librechat/test/test-chart.sh --cleanup
```

## Troubleshooting

### Common Issues

1. **Secret not found**: Ensure the secret specified in `global.librechat.existingSecretName` exists in the same namespace
2. **Database connection issues**: Check MongoDB/Meilisearch dependency configuration
3. **Image pull errors**: Verify image repository and tag settings
4. **Permission issues**: Check RBAC configuration if using service accounts

### Debugging

- Use `kubectl logs` to check pod logs
- Use `kubectl describe` to check pod/service status
- Enable debug logging by setting `DEBUG_PLUGINS: "true"` in environment variables
- Use `helm template` to debug template rendering issues

## Upgrading

To upgrade the chart:

```bash
helm upgrade librechat ./helm/librechat -f custom-values.yaml
```

## Uninstalling

To uninstall the chart:

```bash
helm uninstall librechat
```

Note: If `librechat.imageVolume.retain` is set to `false`, the persistent volume claim will be deleted along with the release.