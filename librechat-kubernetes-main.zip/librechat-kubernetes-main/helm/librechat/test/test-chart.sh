#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Print section header
section() {
  echo -e "\n${YELLOW}=== $1 ===${NC}"
}

# Print success message
success() {
  echo -e "${GREEN}✓ $1${NC}"
}

# Print error message and exit
error() {
  echo -e "${RED}✗ $1${NC}"
  exit 1
}

# Check if required tools are installed
check_requirements() {
  section "Checking requirements"
  
  if ! command -v helm &> /dev/null; then
    error "Helm is not installed. Please install Helm: https://helm.sh/docs/intro/install/"
  fi
  success "Helm is installed"
  
  if ! command -v kind &> /dev/null; then
    error "Kind is not installed. Please install Kind: https://kind.sigs.k8s.io/docs/user/quick-start/#installation"
  fi
  success "Kind is installed"
  
  if ! command -v kubectl &> /dev/null; then
    error "Kubectl is not installed. Please install Kubectl: https://kubernetes.io/docs/tasks/tools/install-kubectl/"
  fi
  success "Kubectl is installed"
}

# Run Helm lint
run_lint() {
  section "Running Helm lint"
  
  CHART_DIR="$(dirname "$(dirname "$0")")"
  
  helm lint "$CHART_DIR" || error "Helm lint failed"
  success "Helm lint passed"
}

# Create Kind cluster
create_cluster() {
  section "Creating Kind cluster"
  
  if kind get clusters | grep -q "librechat-test"; then
    echo "Cluster 'librechat-test' already exists, deleting it..."
    kind delete cluster --name librechat-test
  fi
  
  cat > kind-config.yaml << EOF
kind: Cluster
apiVersion: kind.x-k8s.io/v1alpha4
nodes:
- role: control-plane
  extraPortMappings:
  - containerPort: 30080
    hostPort: 30080
    protocol: TCP
EOF
  
  kind create cluster --name librechat-test --config kind-config.yaml || error "Failed to create Kind cluster"
  success "Kind cluster created"
  
  # Set kubectl context to the new cluster
  kubectl cluster-info --context kind-librechat-test
}

# Install chart dependencies
install_dependencies() {
  section "Installing chart dependencies"
  
  CHART_DIR="$(dirname "$(dirname "$0")")"
  
  helm repo add bitnami https://charts.bitnami.com/bitnami
  helm repo add meilisearch https://meilisearch.github.io/meilisearch-kubernetes
  helm dependency update "$CHART_DIR" || error "Failed to update dependencies"
  success "Dependencies updated"
}

# Install chart
install_chart() {
  section "Installing chart"
  
  CHART_DIR="$(dirname "$(dirname "$0")")"
  
  # Create test values file
  cat > test-values.yaml << EOF
replicaCount: 1

# Disable dependencies for faster testing
mongodb:
  enabled: false

meilisearch:
  enabled: false

librechat-rag-api:
  enabled: false

# Create test secrets
librechat:
  configEnv:
    CREDS_KEY: 9e95d9894da7e68dd69c0046caf5343c8b1e80c89609b5a1e40e6568b5b23ce6
    CREDS_IV: ac028c86ba23f4cd48165e0ca9f2c683
    JWT_SECRET: 16f8c0ef4a5d391b26034086c628469d3f9f497f08163ab9b40137092f2909ef
    JWT_REFRESH_SECRET: eaa5191f2914e30b9387fd84e254e4ba6fc51b4654968a9b0803b456a54b8418

# Use smaller resource requests for testing
resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 100m
    memory: 128Mi

# Enable NodePort for local testing
service:
  type: NodePort
  nodePort: 30080
EOF
  
  # Create namespace
  kubectl create namespace librechat-test || true
  
  # Create test secrets
  kubectl create secret generic librechat-credentials-env \
    --namespace librechat-test \
    --from-literal=OPENAI_API_KEY=sk-test-key \
    --from-literal=MEILI_MASTER_KEY=test-meili-key \
    --dry-run=client -o yaml | kubectl apply -f -
  
  # Install chart
  helm install librechat-test "$CHART_DIR" \
    --namespace librechat-test \
    --values test-values.yaml \
    --wait --timeout 5m || error "Failed to install chart"
  
  success "Chart installed"
}

# Test chart
test_chart() {
  section "Testing chart"
  
  # Wait for pods to be ready
  echo "Waiting for pods to be ready..."
  kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=librechat --namespace librechat-test --timeout=300s || error "Pods did not become ready"
  
  # Run the built-in Helm test
  echo "Running Helm test..."
  helm test librechat-test --namespace librechat-test || error "Helm test failed"
  
  # Get all resources for debugging
  echo "Deployed resources:"
  kubectl get all --namespace librechat-test
  
  # Verify service is accessible
  echo "Verifying service accessibility..."
  kubectl run curl-test --image=curlimages/curl --namespace librechat-test --rm -it --restart=Never -- \
    curl -s http://librechat-test:8080 -o /dev/null -w "%{http_code}\n" || true
  
  success "Chart tests passed"
  
  echo -e "\n${GREEN}The LibreChat Helm chart has been successfully installed and tested.${NC}"
  echo -e "You can access the application at http://localhost:30080"
  echo -e "To clean up, run: ${YELLOW}./$(basename "$0") --cleanup${NC}"
}

# Clean up
cleanup() {
  section "Cleaning up"
  
  helm uninstall librechat-test --namespace librechat-test 2>/dev/null || true
  kubectl delete namespace librechat-test 2>/dev/null || true
  kind delete cluster --name librechat-test 2>/dev/null || true
  rm -f test-values.yaml kind-config.yaml
  
  success "Cleanup completed"
}

# Main function
main() {
  if [ "$1" == "--cleanup" ]; then
    cleanup
    exit 0
  fi
  
  check_requirements
  run_lint
  create_cluster
  install_dependencies
  install_chart
  test_chart
}

# Run main function with all arguments
main "$@"